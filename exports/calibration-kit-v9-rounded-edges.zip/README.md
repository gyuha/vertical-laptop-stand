# 하중 작동식 랩탑 세로 스탠드

고무줄로 평소에는 벌어지고, 노트북 무게로 중앙이 내려가며 양쪽이 모이는 출력 스탠드를 설계합니다. TPU와 금속 축 없이 출력 축을 사용합니다.

현재 제공하는 것은 **지지벽의 앞뒤 폭을120mm(12cm)로 맞춘 PLA 설계 시제품**입니다. 실제 조립·복원·안정성을 확인한 뒤 후속 설계와 PETG 제작에 반영합니다.

수정본은 상부 돌출 멈춤 기구를 제거하고 **경첩 하단의 일체형 턱끼리 맞닿아 벌림을 제한**합니다. 닫히는 폭은 노트북과 펠트의 접촉으로 정합니다.

고무줄은 **전면 하단 가로부의 뒷면에서 안쪽으로 향하는 수평 걸이 한 쌍**에 연결합니다. 별도의 아래 선반과 수직 걸이는 없습니다.

걸이 양끝은 뾰족한 돌출 없이 다리와 이어지는 사선으로 다듬고 모서리는 둥글게 마감했습니다.

지지벽과 바닥 발의 바깥 테두리는 R1mm 필렛으로 부드럽게 마감했습니다.

1. [출력·조립 안내](docs/calibration.md)를 읽고 `exports/calibration/fit-plate.stl`부터 출력합니다.
2. 맞는 축 여유를 확인한 뒤 지지대 시험편을 조립합니다.
3. 안내 문서 마지막의 결과 양식을 보내 주세요.

- 원본 보존: `references/`
- 수정 가능한 소스: `cad/parameters.json`, `cad/build_calibration.py`
- FreeCAD: `cad/calibration.FCStd`, `cad/mechanism-assembly.FCStd`
- 출력 부품: `exports/calibration/`
- 검사·렌더링: `docs/evidence/`

형상 검사: `python3 scripts/check_geometry.py --target calibration`
