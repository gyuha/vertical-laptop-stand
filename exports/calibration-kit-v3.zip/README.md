# 하중 작동식 랩탑 세로 스탠드

고무줄로 평소에는 벌어지고, 노트북 무게로 중앙이 내려가며 양쪽이 모이는 출력 스탠드를 설계합니다. TPU와 금속 축 없이 출력 축을 사용합니다.

현재 제공하는 것은 **PLA 경첩·복원 시험편**입니다. 전체 스탠드는 실제 시험 결과를 받은 뒤 제작하며, PETG 최종 제작도 별도 확인이 필요합니다.

수정본은 상부 돌출 멈춤 기구를 제거하고 **경첩 하단의 일체형 턱끼리 맞닿아 벌림을 제한**합니다. 닫히는 폭은 노트북과 펠트의 접촉으로 정합니다.

고무줄은 **두 받침 사이 하단 내부의 수직 걸이**에 연결하며 앞쪽으로 돌출된 걸이를 제거했습니다.

1. [출력·조립 안내](docs/calibration.md)를 읽고 `exports/calibration/fit-plate.stl`부터 출력합니다.
2. 맞는 축 여유를 확인한 뒤 지지대 시험편을 조립합니다.
3. 안내 문서 마지막의 결과 양식을 보내 주세요.

- 원본 보존: `references/`
- 수정 가능한 소스: `cad/parameters.json`, `cad/build_calibration.py`
- FreeCAD: `cad/calibration.FCStd`, `cad/mechanism-assembly.FCStd`
- 출력 부품: `exports/calibration/`
- 검사·렌더링: `docs/evidence/`

형상 검사: `python3 scripts/check_geometry.py --target calibration`
