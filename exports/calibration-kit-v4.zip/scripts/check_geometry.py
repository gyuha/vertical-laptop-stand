"""Inspect exported meshes and the actual solid assembly, not just filenames.

The normal Python entry point invokes the FreeCAD kernel using the local launcher.
No printer, cloud account or network connection is used.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]


def mesh_vertices(path):
    data=path.read_bytes()
    if len(data)>=84 and 84+50*struct.unpack_from('<I',data,80)[0]==len(data):
        return [[struct.unpack_from('<3f',data,84+i*50+12+j*12) for j in range(3)]
                for i in range(struct.unpack_from('<I',data,80)[0])]
    pts=[tuple(map(float,line.split()[1:4])) for line in data.decode().splitlines()
         if line.strip().startswith('vertex ')]
    assert len(pts)%3==0, f'Broken STL: {path}'
    return [pts[i:i+3] for i in range(0,len(pts),3)]


def inspect_mesh(path, expected_components=1):
    tris=mesh_vertices(path)
    assert tris, f'Empty mesh: {path}'
    edges=Counter()
    directed=Counter()
    area_min=float('inf')
    volume=0
    verts=set()
    parent={}
    def find(v):
        parent.setdefault(v,v)
        while parent[v]!=v:
            parent[v]=parent[parent[v]]
            v=parent[v]
        return v
    for tri in tris:
        assert all(math.isfinite(c) for v in tri for c in v), f'Nonfinite: {path}'
        a,b,c=tri
        ab=[b[i]-a[i] for i in range(3)]
        ac=[c[i]-a[i] for i in range(3)]
        cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
        area=math.sqrt(sum(x*x for x in cross))/2
        area_min=min(area_min,area)
        assert area>1e-9, f'Degenerate triangle: {path}'
        volume+=sum(a[i]*[b[1]*c[2]-b[2]*c[1],b[2]*c[0]-b[0]*c[2],b[0]*c[1]-b[1]*c[0]][i] for i in range(3))/6
        q=[tuple(round(v,5) for v in p) for p in tri]
        verts.update(q)
        for i in range(3):
            x,y=q[i],q[(i+1)%3]
            edges[tuple(sorted((x,y)))]+=1
            directed[(x,y)]+=1
            px,py=find(x),find(y)
            parent[px]=py
    assert all(n==2 for n in edges.values()), f'Open/nonmanifold mesh: {path}'
    assert all(directed[(a,b)]==directed[(b,a)] for a,b in edges), f'Inconsistent winding: {path}'
    components=len({find(v) for v in verts})
    assert components==expected_components, f'{path}: {components} components, expected {expected_components}'
    assert volume>0, f'Nonpositive volume: {path}'
    lo=[min(p[i] for p in verts) for i in range(3)]
    hi=[max(p[i] for p in verts) for i in range(3)]
    assert lo[2]>=-1e-4, f'Below build plate: {path}'
    assert all(hi[i]-lo[i]<246 for i in range(3)), f'No printer margin: {path}'
    return {'file':path.name,'triangles':len(tris),'components':components,
            'volume_mm3':round(volume,3),'bounds_mm':[lo,hi],
            'min_triangle_area_mm2':area_min}


def kernel_check():
    # Import the same editable geometry, but independently measure intersections,
    # surface positions, rotation limits, and floor clearance of the resulting BReps.
    sys.path.insert(0,str(ROOT/'cad'))
    import FreeCAD as App
    import Part
    import Mesh
    import build_calibration as cad
    p=cad.P
    left,right=cad.make_half(True),cad.make_half(False)
    for s in [left,right]:
        assert s.isValid() and len(s.Solids)==1
        s.check(True)
    for x in p['hook_x']:
        mid_y=(p['hook_mount_y']+p['hook_neck_end_y'])/2
        assert left.isInside(App.Vector(-x,mid_y,p['hook_z']),1e-6,True), 'Reversed shaft missing'
        assert not left.isInside(App.Vector(-x,-1,p['hook_z']),1e-6,True), 'Hook points out of front'
        tip=Part.Vertex(App.Vector(-x,p['hook_head_end_y'],p['hook_z']))
        assert left.distToShape(tip)[0]<1e-6,'Hook tip not at the back face'
    for x in [-20,-15,-10,-7]:
        assert not left.isInside(App.Vector(x,16,-14),1e-6,True),'Unwanted lower hook platform remains'
    common=[]
    floor=[]
    laptop_contacts=[]
    band_clearances=[]
    for side in [left,right]:
        assert side.BoundBox.YMin>=-1e-6 and side.BoundBox.YMax<=p['depth']+1e-6, 'Front hook protrusion remains'
    for i in range(33):
        angle=p['sample_loaded_angle_deg']*i/32
        a=cad.assembly_pose(left,angle,True)
        b=cad.assembly_pose(right,angle,False)
        volume=a.common(b).Volume
        common.append(volume)
        floor.append(min(a.BoundBox.ZMin,b.BoundBox.ZMin))
        theta=math.radians(angle)
        h=p['foot_drop']*math.cos(theta)-(p['foot_x']-12)*math.sin(theta)
        half=p['laptop_thickness']/2
        seat=h+9/math.cos(theta)+half*math.tan(theta)
        laptop=Part.makeBox(p['laptop_thickness'],p['depth'],100,
                            App.Vector(-half,0,seat))
        for body in [a,b]:
            assert body.common(laptop).Volume<1e-5, f'Laptop collides with stop or body at {angle}'
        distances=[s.distToShape(laptop)[0] for s in [a,b]]
        assert max(distances)<1e-5, f'Laptop not seated on both cradles: {distances}'
        laptop_contacts.append({'angle_deg':angle,'seat_height_mm':seat,'shelf_distances_mm':distances})
        axle=cad.make_pin()
        axle.translate(App.Vector(0,0,h))
        for index in range(len(p['hook_x'])):
            points=cad.band_path(index,angle)
            wire=Part.makePolygon(points)
            distances=[wire.distToShape(body)[0] for body in [a,b,axle]]
            clearance=min(distances)-p['band_wire_radius']
            assert clearance>0.05, f'Internal band collides at {angle} deg / pair {index}: {clearance}'
            assert min(pt.z for pt in points)>p['band_wire_radius']+1, 'Band too near floor'
            assert min(pt.y for pt in points)>p['band_wire_radius'], 'Band protrudes at front'
            assert max(pt.y for pt in points)<p['depth']-p['band_wire_radius'], 'Band protrudes at back'
            band_clearances.append(clearance)
    assert max(common)<1e-5, f'Body interference: {max(common)} mm3'
    assert min(floor)>-1e-5, f'Floor interference: {min(floor)} mm'
    outside=[]
    for angle in [-0.1,-2]:
        a=cad.assembly_pose(left,angle,True)
        b=cad.assembly_pose(right,angle,False)
        overlap=a.common(b).Volume
        assert overlap>0.01, f'No physical rotation stop at {angle} deg'
        outside.append({'angle_deg':angle,'stop_overlap_mm3':overlap})
    # Solid intersections intentionally omit touching boundary faces; intersect
    # the two actual under-axis X=0 boundary faces to measure their contact patch.
    faces=[]
    for body in [left,right]:
        matching=[f for f in body.Faces if abs(f.BoundBox.XMin)<1e-7
                  and abs(f.BoundBox.XMax)<1e-7 and f.BoundBox.ZMax<0]
        assert len(matching)==1,'Missing integral stop face'
        faces.append(matching[0])
    shoulder_contact=faces[0].common(faces[1])
    expected_area=(p['opening_stop_top_z']-p['opening_stop_bottom_z'])*p['opening_stop_depth']
    assert abs(shoulder_contact.Area-expected_area)<1e-5, 'Lower stop faces do not mate fully'
    assert shoulder_contact.BoundBox.ZMax<0, 'Opening stop must be below the joint'
    # There is no separate closing limiter. Past the nominal laptop pose the
    # empty mechanism must remain free; the real device/pads establish contact.
    extra_angle=p['sample_loaded_angle_deg']+2
    extra_a=cad.assembly_pose(left,extra_angle,True)
    extra_b=cad.assembly_pose(right,extra_angle,False)
    assert extra_a.common(extra_b).Volume<1e-5,'Unwanted closing stop remains'
    # Verify JSON dimensions correspond to material on the exported bodies.
    for point in [(-p['foot_x'],16,-p['foot_drop']),
                  (-p['wall_inner_x']-0.4,16,p['wall_top'])]:
        dist=left.distToShape(Part.Vertex(App.Vector(*point)))[0]
        assert dist<1e-6, f'Parameter/solid mismatch at {point}: {dist}'
    axle=cad.make_pin()
    for angle in [0,p['sample_loaded_angle_deg']]:
        for body,sign in [(left,1),(right,-1)]:
            moving=body.copy()
            moving.rotate(App.Vector(0,0,0),App.Vector(0,1,0),angle*sign)
            assert moving.common(axle).Volume<1e-5, 'Axle blocked by a later solid addition'
    self_intersections=[]
    for path in sorted((ROOT/'exports/calibration').glob('*.stl')):
        m=Mesh.Mesh(str(path))
        if hasattr(m,'hasSelfIntersections'):
            assert not m.hasSelfIntersections(), f'Mesh self intersections: {path}'
            self_intersections.append(path.name)
    # The main axle inserts parallel to Y after the two bodies mate.
    insertion=[]
    for i in range(81):
        moving=right.copy()
        moving.translate(App.Vector(40*(80-i)/80,0,0))
        assert moving.common(left).Volume<1e-5,'Bodies cannot mate with pins removed'
    for name,pin,delta in [('main',cad.make_pin(),-1)]:
        for step in range(41):
            offset=delta*(40-step)
            moving=pin.copy()
            moving.translate(App.Vector(0,offset,0))
            volume=moving.common(left).Volume+moving.common(right).Volume
            assert volume<1e-5,f'{name} pin has blocked insertion at {offset}mm: {volume}'
        insertion.append(name)
    for which in ['main']:
        key=cad.key_in_assembly()
        for i in range(41):
            moving=key.copy()
            moving.translate(App.Vector(-(40-i),0,0))
            bodies=[left,right,cad.make_pin()]
            overlap=sum(moving.common(b).Volume for b in bodies)
            assert overlap<1e-5,f'{which} key has blocked insertion at {40-i}mm: {overlap}'
        insertion.append(which+'-key')
    return {'max_body_overlap_mm3':max(common), 'minimum_floor_clearance_mm':min(floor),
            'pose_samples':len(common),'physical_stop_checks':outside,
            'opening_stop_contact_area_mm2':shoulder_contact.Area,
            'opening_stop_contact_bounds':str(shoulder_contact.BoundBox),
            'no_closing_limiter_check_deg':extra_angle,
            'internal_band_paths_checked':len(band_clearances),
            'minimum_band_surface_clearance_mm':min(band_clearances),
            'hook_direction':[0,1,0],
            'hook_mount_y_mm':p['hook_mount_y'],
            'hook_tip_y_mm':p['hook_head_end_y'],
            'lower_hook_platform_removed':True,
            'laptop_contacts':laptop_contacts,'pin_insertion_paths_checked':insertion,
            'mesh_self_intersections_checked':self_intersections}


def motion_check(p):
    rows=[]
    for i in range(33):
        angle=p['sample_loaded_angle_deg']*i/32
        t=math.radians(angle)
        h=p['foot_drop']*math.cos(t)-(p['foot_x']-12)*math.sin(t)
        # Inner face ends, after the 0.4mm-deep felt pocket; pad proud = 0.6mm.
        pad_proud=p['felt_thickness']-0.4
        gap=2*((p['wall_inner_x']-pad_proud)*math.cos(t)-p['wall_top']*math.sin(t))
        hook_clearance=min(h+x*math.sin(t)+p['hook_z']*math.cos(t)-p['hook_head_radius']
                           for x in p['hook_x'])
        spans=[2*(x*math.cos(t)-p['hook_z']*math.sin(t)) for x in p['hook_x']]
        # A horizontal inward force F at a left anchor gives tau_y=z*F (<0),
        # opposite the left body's positive closing rotation. Unit force is enough
        # to check sign; stiffness/preload and friction remain physically unmeasured.
        torque_per_newton=[x*math.sin(t)+p['hook_z']*math.cos(t) for x in p['hook_x']]
        assert all(x<0 for x in torque_per_newton), 'Band torque reversed'
        assert hook_clearance>1.0, f'Insufficient lower-hook clearance: {hook_clearance}'
        rows.append({'angle_deg':angle,'hinge_height_mm':h,'felt_gap_mm':gap,
                     'hook_clearance_mm':hook_clearance,'band_spans_mm':spans,
                     'opening_torque_mm_per_N':torque_per_newton})
    for a,b in zip(rows,rows[1:]):
        assert b['hinge_height_mm']<a['hinge_height_mm']
        assert b['felt_gap_mm']<a['felt_gap_mm']
        assert all(y>x for x,y in zip(a['band_spans_mm'],b['band_spans_mm']))
    assert rows[0]['felt_gap_mm']>p['laptop_thickness']>rows[-1]['felt_gap_mm']
    # Cradle face x=-10,z=9: downward force causes closing, and the face descends.
    rows0=9+p['foot_drop']
    t=math.radians(p['sample_loaded_angle_deg'])
    rows1=10*math.sin(t)+9*math.cos(t)+rows[-1]['hinge_height_mm']
    assert rows1<rows0
    return rows


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--target',choices=['calibration','stand'],required=True)
    parser.add_argument('--kernel',action='store_true')
    args=parser.parse_args()
    if args.target=='stand':
        raise SystemExit('Full stand is waiting for physical calibration feedback; no success result is available.')
    if args.kernel:
        print(json.dumps(kernel_check()))
        return
    out=ROOT/'exports/calibration'
    manifest=json.loads((out/'manifest.json').read_text())
    checks=[inspect_mesh(out/p['file']) for p in manifest['parts']]
    checks += [inspect_mesh(out/'calibration-plate.stl',7),inspect_mesh(out/'fit-plate.stl',5)]
    # Fixed plate placement is measured from the actual STL, including the excluded
    # front-left X1C rectangle (x<18,y<28) and a 5mm edge margin.
    for filename in ['calibration-plate.stl','fit-plate.stl']:
        tris=mesh_vertices(out/filename)
        points=[p for tri in tris for p in tri]
        assert all(5<=p[0]<=251 and 5<=p[1]<=251 for p in points)
        assert not any(p[0]<18 and p[1]<28 for p in points), 'X1C excluded region'
    p=json.loads((ROOT/'cad/parameters.json').read_text())
    motion=motion_check(p)
    proc=subprocess.run(['bash',str(ROOT/'scripts/freecad_python.sh'),str(Path(__file__).resolve()),
                         '--target','calibration','--kernel'],cwd=ROOT,text=True,capture_output=True)
    if proc.returncode:
        raise SystemExit(proc.stdout+proc.stderr)
    solid=json.loads(proc.stdout.strip().splitlines()[-1])
    for name,expected in [('body-original.stl','f7671db9738a397e7554e37b29e71e9952b0535ff57e6514d50c0abb74338316'),
                          ('connector-original.stl','e8e561727ff7b86b839c156620de23dbdaed1f730be9b08e3b653d288fde108c')]:
        assert hashlib.sha256((ROOT/'references'/name).read_bytes()).hexdigest()==expected
    report={'result':'pass','scope':'digital calibration geometry only; physical performance unverified',
            'parameters_sha256':hashlib.sha256((ROOT/'cad/parameters.json').read_bytes()).hexdigest(),
            'generator_sha256':hashlib.sha256((ROOT/'cad/build_calibration.py').read_bytes()).hexdigest(),
            'artifact_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest()
                               for f in sorted(out.glob('*.stl'))},
            'meshes':checks,'solid_assembly':solid,'motion':motion}
    (ROOT/'docs/evidence/geometry-report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'PASS: {len(checks)} STL files; {len(motion)} motion poses; solid interference and stop checks passed.')
    print('Physical fit, friction, force balance and durability: NOT TESTED.')


if __name__=='__main__':
    main()
